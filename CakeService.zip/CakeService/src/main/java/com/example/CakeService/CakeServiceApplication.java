package com.example.CakeService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CakeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CakeServiceApplication.class, args);
	}

}
